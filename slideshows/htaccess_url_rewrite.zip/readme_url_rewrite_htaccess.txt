In this zip file is an example .htaccess file to enable url rewrite.
Please see http://www.tinywebgallery.com/en/faq.php#h44 for details because
other settings are needed and also the .htaccess has to be adopted to your paths.

There is another .htaccess (htaccess_optimize.zip) provided for optimizing TWG. 
You can simply join the files if you like. 
See http://www.tinywebgallery.com/en/faq.php#h45

Have fun using TWG,
Michael