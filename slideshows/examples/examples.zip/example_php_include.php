<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 transitional//EN">
<html>
<head>
<META http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>TWG include example</title>
<style type="text/css">

.top {
	background : #eeeeee;
	padding: 3px;
}
.left {
	background : #cccccc;
	padding: 3px;
}


</style>
<title>TinyWebGallery integration example</title>
</head>

<body style="margin:0px;padding:0px">
<table summary="" cellpadding='0' cellspacing='0' border='1' style="height:100%">
<tr>
<td colspan=2 height="70" class="top">
Top row - the borders of the table is set to 1. if you use include - the only problem could be the stylesheet where some parts could overwritten. If you have weired displays - this is the place to search ;)<br>
</td>
</tr>
<tr>
<td class="left">Here comes maybe&nbsp;the&nbsp;navigation of your web page- use a spacerimage for exact width of this cell<br>&nbsp;<br><br/> Or you can display a random image here:<br/>&nbsp;<br>
<a href ='example_php_include.php?twg_random=1'>
<img alt="" src="image.php?&twg_random_subdir=true&amp;twg_random=1&amp;twg_type=random&amp;twg_random_size=100" />
</a>
</td>
<td width="100%" height="100%"><?php include "index.php"  ?>
</td>
</tr>
</table>
</body>
</html>