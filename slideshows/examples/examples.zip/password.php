<?php
/*************************  
  @HEADER@
  $Date: 2009-06-17 22:57:10 +0200 (Mi, 17 Jun 2009) $
  $Revision: 73 $
**********************************************/

require ( dirname(__FILE__) . "/config.php");
include ("inc/sha256.inc.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Password sha1/256 generator for TWG</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" type="text/css" href="style.css" >
</head>
<body>
<table class='twg' summary=""><tr><td>
<h4>Password generator for TinyWebGallery 1.7</h4>
Enter password and press generate:
<form action="password.php" method="post">
<input name="password" type="text" size="30" maxlength="30">
<input name="" type="submit" value="Generate">
</form>
<?php
if (isset( $_POST['password'])) {

     $pas = replaceInput($_POST['password']);
     
	 if (function_exists("sha1") && $use_sha1_for_password) {
      echo "SHA1 hash value for '" . $pas . "': '" . sha1($pas) . "'";
	 } else {
	 if (!function_exists("sha1") && $use_sha1_for_password) {
	 echo "SHA1 does not exist - using interneal SHA256 instead!<br>";
	 }
	    echo "SHA256 hash value '" . $pas . "': '" . sha2($pas) . "'";
	 
	 }
}
?>
<p>Copy the generated value to your config.php -> $privatepassword or into one of your password files.<br/>
If you want to use more than one password for a gallery plese seperate the password with a ',' like<br/>
388ad1c312a488ee9e12998fe097f2258fa8d5ee,a17fed27eaa842282862ff7c1b9c8395a26ac320</p>
</td></tr></table>
</body>
</html>

<?php 
function replaceInput($input)
{
	$output = str_replace("<", "_", $input);
	$output = str_replace(">", "_", $output);
	$output = str_replace(";", "_", $output);
	$output = str_replace("'", "_", $output);
	// we check some other settings too :)
	if (strpos($output, "cookie(") || strpos($output, "popup(") || strpos($output, "open(") || strpos($output, "alert(") || strpos($output, "reload(") || strpos($output, "refresh(")) {
		$output = "error";
	}
	// we check for security if a .. is in the path we remove this!	and .// like in http:// is invalid too!
	$output = ereg_replace("\.\.", "__", $output);
	$output = ereg_replace("://", "___", $output);
	return $output;
}
?>
