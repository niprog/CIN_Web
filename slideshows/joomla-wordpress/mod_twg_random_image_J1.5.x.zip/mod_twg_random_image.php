<?php
/**
* @version $Id: mod_random_image.php 85 2005-09-15 23:12:03Z eddieajau $
* @package Joomla
* @copyright Copyright (C) 2005 Open Source Matters. All rights reserved.
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
* Joomla! is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

$folder 		= $params->get( 'folder' );
$album 		  = $params->get( 'album' );
$recusive   = $params->get( 'recusive','1' );
$id         = $params->get( 'id','1' );
$type       = $params->get( 'type','1' );
$link 			= $params->get( 'link' );
$target 		= $params->get( 'target' );
$size 			= $params->get( 'size' );
$margin 		= $params->get( 'margin' );
$slideshow 	= $params->get( 'slideshow' );
$time 			= $params->get( 'time');
$savespace 	= $params->get( 'savespace' );

if ($type) {
  $type_str = "random";
} else {
  $type_str = "top";
}
$imageurl = $folder . "/image.php?twg_album=" . $album . "&twg_random=". $id ."&twg_type=". $type_str ."&twg_random_size=" . $size;

if ($recusive) {
  $imageurl .= "&twg_random_subdir=true";
}
$strheight = "";
if ($savespace) {
  $strheight = " style='height:" . ($size+($margin*2) + 4) . "px;' ";
}
?>
  
<center>	
 	<table align="center" cellspacing="0" cellpadding="0" border="0" <?php echo $strheight; ?>><tr><td align="center">
 	<center>
 	<?php
  	if ($link) {
  		?>
  		<a href="<?php echo $link; ?>?twg_random=<?php echo $id; ?>" target="<?php echo $target; ?>">
  		<?php
  	}
  	?> 	
  	
 	<img id="twg_rand_img" align="center" name="twg_rand_img" style="margin:<?php echo $margin; ?>px" src="<?php echo $imageurl; ?>" border="0" alt="" /> 
  
 <?php
  	if ($link) {
  		?>
  		</a>
  		<?php
  	}
  	?>
   </center></td></tr></table>
</center>
 	
<?php 
 if ($slideshow) {
  echo "<script>window.setTimeout(\"changeImage()\"," . ($time * 1000) . "); </script>";
 }
?>
<script>
	var timer = 0;
	function changeImage() {
	 document.images.twg_rand_img.src='<?php echo $imageurl ?>&timer=' + timer++;
	 window.setTimeout("changeImage()",<?php echo ($time * 1000); ?>); 
	}
</script>


 	
 	