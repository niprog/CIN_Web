<?php


// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

$my = JFactory::getUser();
    
if (isset($my) &&  isset($my->username) && $my->username != "") {
  $_SESSION["s_user"] = $my->username;
}

$link 			= $params->get( 'link' );
$sizex 			= $params->get( 'sizex' );
$sizey 			= $params->get( 'sizey' );
$scrollbar  = $params->get( 'scrollbar' );
$addalbum       = $params->get( 'addalbum' );

$scroll = " SCROLLING=NO ";
if ($scrollbar) {
  $scroll = ""; 
}

// we include the lytebox css
echo '<link rel="stylesheet" href="' . dirname($link) . '/lightbox/lytebox.css" type="text/css" media="screen"> ';

if ($addalbum == '1' && isset($_SESSION["s_user"])) {
   // maybe a parameter is already there then we append with & otherwiese with ?
   $link .= ((strpos($link , '?') === false) ? '?' : '&amp;') . "twg_album=" . urlencode($_SESSION["s_user"]); 
}

fixSession();
echo '<iframe name="twg_iframe" FRAMEBORDER="0" allowtransparency=true 
src="' . $link . '" width="' . $sizex . '" height="' . $sizey . '" ' . $scroll . '></iframe>';
/*
  This is needed because twg needs the session variables right away. To avoid
  timing problems I write the session and reload it again!
*/
function fixSession() {
  ob_start();     
  // this is a fix if session are not saved and passed to the config.php
  $HTTP_SESSION_VARS = $_SESSION;
  session_write_close();
  ini_set('session.save_handler', 'files');
  session_start();
  $_SESSION = $HTTP_SESSION_VARS; 
  session_write_close();
  ob_end_clean();
  // end fix ;).  
  }
?>

 	
 	