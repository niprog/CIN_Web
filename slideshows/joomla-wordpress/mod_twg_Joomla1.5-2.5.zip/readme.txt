This is the module to include TinyWebGallery to Joomla 1.5 up to Joomla 2.5

To install it properly you have to have a TWG installation somewhere.
In the module settings you have to specify the installation directory 
with the main index file. e.g. ../TinyWebGallery/index.php

If you want to use a component please use the wrapper that comes with Joomla.
Just link to your TWG installation there ;).

To include a module in the content please google for mosmodule.

This module does automatically set the login name to the session as 's_user'.
In TWG it's possible that comments can only be made if a user was registered
in Joomla (see $enable_comments_only_registered). 
No real login to TWG is made because no password is provided.
This variable is also used for the multi root mode. Read howto 52 of the TWG howtos.

Have fun using this module.

- Michael