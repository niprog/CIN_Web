This is the random image of TinyWebGallery for Joomla 1.0.x/Mambo

To install it properly you have to have a TWG installation somewhere.
In the module settings you have to specify the installation directory.
e.g. ../TinyWebGallery

Have fun using this module.

/Michael