In this zip file is a .htaccess file to protect all .txt and .xml files.
Please use this to protect your files like private.txt, folder.txt ...

This file does also optimize TWG by enabling server compression and caching. 
Please see http://www.tinywebgallery.com/en/faq.php#h45 for details.

I only don't use this file as default because maybe you use a server
that does support the FilesMatch setting.

If possible you should use this file ;).
If you extract the .htaccess and can call the index.php everything is fine.

There is another .htaccess (url_rewrite_htaccess.zip) provided for rewriting the urls. 
You can simply join the files if you like. See: http://www.tinywebgallery.com/en/faq.php#h44

Have fun using TWG,
Michael